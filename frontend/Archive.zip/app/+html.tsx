// frontend/app/+html.tsx
import * as React from "react";

export default function HTML({ children }: { children: React.ReactNode }) {
  // Force a white page background on web
  return (
    <html>
      <head />
      <body style={{ margin: 0, backgroundColor: "#ffffff", color: "#111827" }}>
        {children}
      </body>
    </html>
  );
}
