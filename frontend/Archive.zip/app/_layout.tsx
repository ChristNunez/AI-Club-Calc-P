// app/_layout.tsx
import React from "react";
import { Stack } from "expo-router";
import { ThemeProvider, DarkTheme as NavDarkTheme } from "@react-navigation/native";
import { StatusBar } from "expo-status-bar";

const colors = {
  bg: "#0f172a",       // background
  card: "#0b1220",     // cards / inputs
  text: "#dbeafe",     // near-white text
  primary: "#1d4ed8",  // primary button
  primaryMuted: "#1e3a8a",
  border: "#0b1220",
};

const AppTheme = {
  ...NavDarkTheme,
  colors: {
    ...NavDarkTheme.colors,
    background: colors.bg,
    card: colors.card,
    text: colors.text,
    primary: colors.primary,
    border: colors.border,
    notification: colors.primaryMuted,
  },
};

export default function RootLayout() {
  return (
    <ThemeProvider value={AppTheme}>
      <StatusBar style="light" />
      <Stack
        screenOptions={{
          headerShown: false,
          contentStyle: { backgroundColor: colors.bg },
        }}
      />
    </ThemeProvider>
  );
}
