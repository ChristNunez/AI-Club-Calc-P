// app/(tabs)/index.tsx
import { useEffect, useState } from "react";
import {
  SafeAreaView,
  View,
  Text,
  TextInput,
  Pressable,
  StyleSheet,
  Alert,
  Platform,
  ActivityIndicator,
} from "react-native";
import { newProblem, submitAnswer } from "../../src/api";

const BG = "#0f172a";
const CARD = "#0b1220";
const BORDER = "#1e293b";
const TEXT = "#dbeafe";
const MUTED = "#94a3b8";
const BTN = "#1e3a8a";
const BTN2 = "#1d4ed8";
const BTN_TEXT = "#e2e8f0";

export default function HomeTab() {
  const [problemId, setProblemId] = useState<string | null>(null);
  const [prompt, setPrompt] = useState("Loading…");
  const [answer, setAnswer] = useState("");
  const [feedback, setFeedback] = useState("");
  const [loading, setLoading] = useState(false);

  async function loadProblem() {
    setLoading(true);
    setProblemId(null);
    setPrompt("Loading…");
    setAnswer("");
    setFeedback("");
    try {
      const data = await newProblem("easy");
      setProblemId(data.problem_id);
      setPrompt(data.prompt);
    } catch (e) {
      console.error(e);
      setPrompt("Unable to reach the server. Is the backend on http://127.0.0.1:8005 ?");
    } finally {
      setLoading(false);
    }
  }

  async function checkAnswer() {
    if (!problemId || loading) return;
    setLoading(true);
    try {
      const res = await submitAnswer(problemId, answer);
      const msg = res.feedback || (res.ok ? "Nice!" : "Incorrect");
      setFeedback(msg);
      if (res.ok) {
        Platform.OS === "web" ? window.alert(`✅ Correct!\n${msg}`) : Alert.alert("✅ Correct", msg);
        await loadProblem();
      } else {
        Platform.OS === "web" ? window.alert(`❌ Try again.\n${msg}`) : Alert.alert("❌ Try again", msg);
      }
    } catch (e) {
      console.error(e);
      Platform.OS === "web"
        ? window.alert("Network error. Check the backend.")
        : Alert.alert("Network error", "Check the backend.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadProblem();
  }, []);

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Calcduo</Text>

      <View style={styles.card}>
        <Text style={styles.sectionLabel}>Problem</Text>
        <Text style={styles.prompt}>{prompt}</Text>
      </View>

      <View style={{ marginTop: 12 }}>
        <Text style={styles.sectionLabel}>Your Answer</Text>
        <TextInput
          placeholder="Type f'(x), e.g. 1+12cos(3x-3)"
          value={answer}
          onChangeText={setAnswer}
          autoCapitalize="none"
          autoCorrect={false}
          style={styles.input}
          placeholderTextColor={MUTED}
        />
      </View>

      <View style={styles.row}>
        <Pressable style={[styles.button, loading && styles.btnDisabled]} onPress={checkAnswer} disabled={loading}>
          {loading ? <ActivityIndicator /> : <Text style={styles.buttonText}>CHECK ANSWER</Text>}
        </Pressable>

        <Pressable style={[styles.button, styles.button2, loading && styles.btnDisabled]} onPress={loadProblem} disabled={loading}>
          <Text style={styles.buttonText}>NEW PROBLEM</Text>
        </Pressable>
      </View>

      {!!feedback && <Text style={styles.feedback}>{feedback}</Text>}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: BG, padding: 20 },
  title: { fontSize: 24, fontWeight: "700", color: TEXT, marginBottom: 12 },
  card: {
    borderWidth: 1,
    borderColor: BORDER,
    backgroundColor: CARD,
    borderRadius: 12,
    padding: 12,
  },
  sectionLabel: { color: TEXT, opacity: 0.85, fontSize: 14 },
  prompt: { fontSize: 18, color: TEXT, marginTop: 6 },
  input: {
    borderWidth: 1,
    borderColor: BORDER,
    backgroundColor: CARD,
    color: TEXT,
    borderRadius: 10,
    padding: 12,
    fontSize: 16,
  },
  row: { flexDirection: "row", marginTop: 12 },
  button: {
    flex: 1,
    backgroundColor: BTN,
    paddingVertical: 12,
    borderRadius: 10,
    alignItems: "center",
    marginRight: 8,
    ...(Platform.OS === "web" ? { cursor: "pointer" } : {}),
  },
  button2: { backgroundColor: BTN2, marginRight: 0, marginLeft: 8 },
  btnDisabled: { opacity: 0.85 },
  buttonText: { color: BTN_TEXT, fontWeight: "700", letterSpacing: 0.5 },
  feedback: { marginTop: 12, color: TEXT },
});
